$(document).ready(function(){
    $(".btn-3").click(function(){
        $(".form-img-slide").addClass("slide-right");
        $(".form-img-slide").removeClass("slide-left");
        $(this).addClass("hide-btn");
        $(".sing-in").addClass("sing-in-left");
        $(".sing-up").removeClass("sing-up-left");
        $(".btn-2").removeClass("hide-btn");
        $(".sing-up").addClass("re-slide-right");
    });

    $(".btn-2").click(function(){
        $(".form-img-slide").addClass("slide-left");
        $(".form-img-slide").removeClass("slide-right");
        $(this).addClass("hide-btn");
        $(".sing-up").addClass("sing-up-left");
        $(".sing-in").removeClass("sing-in-left");
        $(".btn-3").removeClass("hide-btn");
    });

    // $(".btn-3").click(function(){
    //     $(".form-img-slide").toggleClass("slide-right");
    //     $(this).toggleClass("hide-btn");
    //     $(".sing-in").toggleClass("sing-in-left");
    //     $(".btn-2").toggleClass("hide-btn");
    //     $(".sing-up").toggleClass("re-slide-right");
    // });

    // $(".btn-2").click(function(){
    //     $(".form-img-slide").toggleClass("slide-left");
    //     $(this).toggleClass("hide-btn");
    //     $(".sing-up").toggleClass("sing-up-left");
    //     $(".btn-3").toggleClass("hide-btn");
    //     $(".sing-in").toggleClass("re-slide-left");
    // });
});